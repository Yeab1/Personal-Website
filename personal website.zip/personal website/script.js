

function ReverseAnimate(){
    var elem = document.getElementById("animateRev");
    var pos = 0;
    var id = setInterval(frame, 1/100);
    function frame(){
        if(pos == 600){
            clearInterval(id);
        }else{
            pos+=5;
            elem.style.right = pos+'px';
        }
    }
}
var x =0;
function func(){
    if(x===0){
        ReverseAnimate();
    }
    x++;
}
window.addEventListener("scroll", function(){
    if (document.body.scrollTop > 100 || document.documentElement.scrollTop > 100) {
    document.querySelector('.m').style.display= 'block';
    func();
  } else {
    document.querySelector('.m').style.display = 'none';
}});


function animate(){
    var elem = document.getElementById("animateRev");
    var pos = 0;
    var id = setInterval(frame, 5);
    function frame(){
        if(pos == 40){
            clearInterval(id);
        }else{
            pos+=0.5;
            elem.style.left = pos+'px';
            elem.style.top = ((1*pos)*3/2)+'px';
        }
    }
}

var animationTimer =false;
animate()
function animatePic(){
    var elem = document.getElementById("picAnimate");
    var pos = 0;
    var id = setInterval(frame, 5);
    function frame(){
        if(pos == -210){
            animationTimer=true;
            clearInterval(id);
        }else{
            pos=pos-3;
            elem.style.left = pos/2+'px';
            elem.style.top=((1*pos)/1.3)+'px';
        }
    }
}
animatePic()

//Get the button:
document.getElementById("myBtn").addEventListener('click', function(){
    document.body.scrollBottom = 700; // For Safari
    document.documentElement.scrollBottom = 600; // For Chrome, Firefox, IE and Opera
});

// When the user clicks on the button, scroll to the top of the document
//Get the button:
mybutton = document.getElementById("scrollBtn");

// When the user scrolls down 20px from the top of the document, hide the button
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 10 || document.documentElement.scrollTop > 10) {
    mybutton.style.display = "none";
  } else {
    mybutton.style.display = "block";
  }
}

// When the user clicks on the button, scroll to the about part of the document
function topFunction() {
    var pos = 0;
    var id = setInterval(frame, 5);
    function frame(){
        if(pos>=670){
            clearInterval(id);
        }else{
            pos+=5;
            document.body.scrollTop=pos; // For Safari
            document.documentElement.scrollTop=pos; // For Chrome, Firefox, IE and Opera
        }
    }
  
}
function topFunction2() {
    var pos = 0;
    var id = setInterval(frame, 5);
    function frame(){
        if(pos>=1180){
            element.scrollIntoView(true);
            clearInterval(id);
        }else{
            pos+=5;
            document.body.scrollTop=pos; // For Safari
            document.documentElement.scrollTop=pos; // For Chrome, Firefox, IE and Opera
        }
    }
}
function topFunction3() {
    var pos = 0;
    var id = setInterval(frame, 5);
    function frame(){
        if(pos>=1500){
            element.scrollIntoView(true);
            clearInterval(id);
        }else{
            pos+=5;
            document.body.scrollTop=pos; // For Safari
            document.documentElement.scrollTop=pos; // For Chrome, Firefox, IE and Opera
        }
    }
  
}


var i = 0;
var txt = 'A diligent, motivated and keen programmer.'; /* The text */
var speed = 50; /* The speed/duration of the effect in milliseconds */

function typeWriter() {
  if (i < txt.length) {
    document.getElementById("demo").innerHTML += txt.charAt(i);
    i++;
    setTimeout(typeWriter, speed);
  }
}
typeWriter();


